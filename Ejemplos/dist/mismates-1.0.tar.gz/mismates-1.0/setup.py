from setuptools import setup
setup(
    name="mismates",
    author="Jared",
    description="Ejemplo de paquete distribuible de operaciones simples",
    version="1.0",
    packages=["mismates"]
)