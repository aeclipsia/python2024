def sumar(x,y):
    return x + y

def restar(x,y):
    return x - y